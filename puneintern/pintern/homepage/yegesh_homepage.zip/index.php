<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"type="text/css" href="css/style.css">
    <link rel="stylesheet"type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <style>
        html {
            scroll-behavior: smooth;
        }
    </style>
</head>

<body>
<style>
    /* Navigation bar background color */
    .navbar {
        background-color: #ffffff; /* Change the color as needed */
    }

    /* Navigation links */
    .navbar-nav .nav-link {
        color:  #02236d; /* Change the color as needed */
        font-weight: bold; /* Make the text bold */
        padding: 10px 15px; /* Add padding to the links */
    }

    /* Active link */
    .navbar-nav .nav-item.active .nav-link {
        color:  #02236d; /* Change the color for active links */
    }

    /* Dropdown menu */
    .dropdown-menu {
        background-color: white; /* Change the background color of dropdown menu */
        border: 1px solid #dddddd; /* Add border to the dropdown menu */
    }

    /* Dropdown items */
    .dropdown-menu .dropdown-item {
        color:  #02236d; /* Change the color of dropdown items */
        font-weight: bold; /* Make the text bold */
    }

    /* Navbar toggler icon color */
    .navbar-toggler-icon {
        color: #02236d; /* Change the color of the toggler icon */
    }

    /* Adjust margin-right for the navbar-toggler */
    .navbar-toggler {
        margin-right: 15px; /* Add margin-right for spacing */
    }

     /* Custom CSS to make all carousel images equal in size */
     .carousel-item img {
      height: 500px; /* Adjust the height as needed */
      object-fit: cover; /* Maintain aspect ratio while covering the entire space */
    }
</style>

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <a class="navbar-brand" href="#">Sanity Technology</a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="gallery_fetch.php">Gallery</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="bootcamp_fetch.php">Events</a>
                </li>
                <li class="nav-item active dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownCourses" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Courses
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownCourses">
                        <a class="dropdown-item" href="#">Java Full Stack</a>
                        <a class="dropdown-item" href="#">Python Full stack</a>
                        <a class="dropdown-item" href="#">Web Development</a>
                        <a class="dropdown-item" href="#">Data Analytics</a>
                        <!-- Add more courses as needed -->
                    </div>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Placement</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="about.html">About us</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="center_fetch.php">Franchise</a>
                </li>
                <!-- <li class="nav-item active">
                    <a class="nav-link" href="contact_us.html">Contact us</a>
                </li> -->
            </ul>

        </div>
        

        <!-- Move the following list inside the navbar-collapse div -->
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto ml-auto-mobile">
            <li class="nav-item active dropdown center">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Login<svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20"><path d="M480-120v-80h280v-560H480v-80h280q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H480Zm-80-160-55-58 102-102H120v-80h327L345-622l55-58 200 200-200 200Z"/></svg>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Student Login</a>
                    <a class="dropdown-item" href="#">Employee Login</a>
                    <a class="dropdown-item" href="#">Job-provider Login</a>
                </div>
            </li>
        </ul>
    </div>
</nav>
   
<div id="demo" class="carousel slide" data-ride="carousel" data-interval="3000">


<!-- The slideshow -->
<div class="carousel-inner">
  <div class="carousel-item active">
    <img src="img\Untitled design.png" alt="Los Angeles">
  </div>
  <div class="carousel-item">
    <img src="img\Placement.jpg" alt="Chicago">
  </div>
  <div class="carousel-item">
    <img src="img\training.png" alt="New York">
  </div>
</div>

<!-- Left and right controls -->
<a class="carousel-control-prev" href="#demo" data-slide="prev">
  <span class="carousel-control-prev-icon"></span>
</a>
<a class="carousel-control-next" href="#demo" data-slide="next">
  <span class="carousel-control-next-icon"></span>
</a>
</div>    
<!--About Us-->

<style>
.about-us {
    padding: 0px 0;
}

.about-us .text {
    flex: 1;
    padding: 0 20px;
    color: #02236d;
}

.about-us img {
    width: 150%;
    height: 300px;
    border-radius: 15px;
}

.about-us h1 {
    color: #02236d;
    font-size: 2.5rem;
    margin-bottom: 20px;
}

.about-us p {
    color: #666;
    line-height: 1.6;
    font-size: 1.1em;
}

h2 {
    font-family: Arial, Helvetica, sans-serif;
    font-style: cambria;
    color: rgb(135, 165, 235);
}

</style>
<!-- about us -->

<section class="about-us" id="about-us">
        <div class="text-center">
            <h1 class="m-5"><span class="letter">A</span>bout <span class="letter">U</span>s</h1>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="text">
                        <p style="text-align: justify;">
                        Welcome to the Placement Management System by Sanity! We're dedicated to making the job search and recruitment process easy and efficient for everyone involved.Job seekers can access a wide range of job opportunities across different industries with our user-friendly platform. Our advanced search options help you find the perfect match, and we provide resources to help you improve your resume and ace interviews. Additionally, we offer courses to enhance your skills.
                        </p>
                        <p style="text-align: justify;">Employers can streamline recruitment by posting vacancies, reviewing applications, and managing candidates all in one place. We focus on quality and professionalism, ensuring you have access to top talent.Whether you're a job seeker or employer, Sanity's Placement Management System is here to help. Thank you for choosing us for your professional development and recruitment needs.
                        </p>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="image">
                        <img src="img\about-us.png" alt="About Us Image" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Events-->
    <style>
.image-frame {
    width: 100%; /* Ensure card fills the entire width */
    height: auto; /* Allow card height to adjust based on content */
}

.card {
    height: 100%; /* Make sure card fills the entire height of its container */
    border: 1px solid #ddd; /* Add border to card if needed */
    border-radius: 10px; /* Add border radius to card */
}

.card-img-top {
    width: 100%; /* Ensure image fills the entire width of the card */
    height: auto; /* Allow image height to adjust based on aspect ratio */
}

    </style>
       
    <section class="Events">
    <div class="text-center">
            <h1 class="m-5"><span class="letter">E</span>vents</h1>
        </div>

        <div class="container-fluid">
        <div class="row justify-content-center" id="courseCards">
        <div class="col-lg-3 col-md-2 col-12">
        <div class="image-frame">
       <div class="card">
            <img class="card-img-top img-fluid" src="img\dm.webp" alt="Card image">
            <div class="card-body text-center">
            <h4 class="card-title"> Bootcamp </h4>
            <p class="card-text"> </p>
        </div>
       </div>
    </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
    <div class="image-frame">
       <div class="card">
            <img class="card-img-top img-fluid" src="img\python.webp" alt="Card image">
            <div class="card-body text-center">
            <h4 class="card-title"> Seminar </h4>
            <p class="card-text"> </p>
            </div>
        </div>
    </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
    <div class="image-frame">
       <div class="card">
            <img class="card-img-top img-fluid" src="img\web.webp" alt="Card image">
            <div class="card-body text-center">
            <h4 class="card-title"> Workshop </h4>
            <p class="card-text"> </p>
            </div>
        </div>
    </div>
    </div>
    </section>

    <section class="courses" id="courses">
        <div class="text-center">
            <h1 class="m-5"><span class="letter">O</span>ur <span class="letter">C</span>ourses</h1>
        </div>

        <div class="container-fluid">
        <div class="row justify-content-center" id="courseCards">
        <div class="col-lg-2 col-md-3 col-12">   
        <div class="image-frame">
       <div class="card">
            <img class="card-img-top img-fluid" src="img\IMG-20240328-WA0011.jpg" alt="Card image">
            <div class="card-body text-center">
            <h4 class="card-title"> python </h4>
            <p class="card-text"> </p>
            <a href="#" class="btn btn-primary">  Learn more </a>
        </div>
       </div>
    </div>
    </div>
    
    <div class="col-lg-2 col-md-3 col-12">
    <div class="image-frame">
       <div class="card">
            <img class="card-img-top img-fluid" src="img\IMG-20240328-WA0001.jpg" alt="Card image">
            <div class="card-body text-center">
            <h4 class="card-title"> Core Java </h4>
            <p class="card-text"> </p>
            <a href="#" class="btn btn-primary"> Learn more</a>
            </div>
        </div>
    </div>
    </div>
    <div class="col-lg-2 col-md-3 col-12">
    <div class="image-frame">
       <div class="card">
            <img class="card-img-top img-fluid" src= "img\IMG-20240327-WA0020.jpg" alt="Card image">
            <div class="card-body text-center">
            <h4 class="card-title" > Digital Marketing </h4>
            <p class="card-text"> </p> 
            <a href="#" class="btn btn-primary"> Learn more</a>
            </div>
        </div>
    </div>
    </div>
    <div class="col-lg-2 col-md-3 col-12">
    <div class="image-frame">
       <div class="card">
            <img class="card-img-top img-fluid" src="img\IMG-20240328-WA0008.jpg" alt="Card image">
            <div class="card-body text-center">
            <h4 class="card-title"> PHP </h4>
            <p class="card-text"> </p>
            <a href="#" class="btn btn-primary"> Learn more </a>
        </div>
       </div>
    </div>
    </div>
    <br>
      
</div>
</div>
</div>
</section>

<style>
    /* Gallery */
    .gallery {
        padding: 0px 0;
    }

    .gallery .text {
        flex: 1;
        padding: 0 20px;
        color: #02236d;
    }

    .gallery h1 {
        color: #02236d;
        font-size: 2.5rem;
        margin-bottom: 20px;
    }

    .gallery img {
        width: 100%;
        height: 300px; /* Equal height for all images */
        border-radius: 15px; /* Rounded corners */
    }
  </style>

<!-- <section class="gallery" >
        <div class="text-center">
            <h1 class="m-5"><span class="letter">G</span>allery</h1>
        </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-12">
                <div class="image-frame">
                <img src="img\IMG_20231019_181938_920.webp" class="img-fluid pb-3 ">
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
            <div class="image-frame">
                <img src="img\img-1.webp" class="img-fluid pb-3">
            </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
            <div class="image-frame">
                <img src="img\Placement.jpg" class="img-fluid pb-3">
            </div>
            </div>
        </div>
    </div>
</section> -->

<!-- Contact Section -->

<section class="contact-us">
        <div class="container">
        <div class="text-center">
            <h1><span class="letter">C</span>ontact <span class="letter">U</span>s</h1>
            <p>Feel free to reach out to us for any inquiries or assistance.</p>
            
            <div class="contact-grid row">
                <!-- Location on the left side -->
                <div class="location col-md-6">
                    <div class="google-map position-relative">
                        <iframe width="100%" height="300" frameborder="0" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d476.9662170573857!2d73.84810304454992!3d18.509031103383844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c073767f8aa7%3A0xe3e6073f4930a151!2sprime%20infotech%20solutions!5e0!3m2!1sen!2sin!4v1711514516078!5m2!1sen!2sin"
                            allowfullscreen>
                        </iframe>
                    </div>
                </div>
                <br>
                <!-- Contact form on the right side -->
                <div class="contact-form col-md-6">
                    <form method="post">
                        <input type="text" class="form-control mb-1" placeholder="Name" name="name" required>
                            <br>
                        <div class="row">
                            <div class="col-md-6 ">
                                <!-- Email input -->
                                <div class=" mb-3">
                                    <input type="email" class="form-control" placeholder="Email" name="email" required>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <!-- Phone number input -->
                                <div class=" mb-3">
                                    <input type="tel" class="form-control " placeholder="Phone Number" name="phone" required>
                                </div>
                            </div>
                        </div>

                        <!-- New fields for state, district, subdistrict, and pincode -->
                        <div class="row">
                            <div class="col-md-6   mb-3">
                                <select class="form-select form-control p-2" id="state" name="state" onchange="loadDistricts()" required>
                                    <option value="">Select State</option>
                                    <option value="AndraPradesh">Andhra Pradesh</option>
                                    <option value="ArunachalPradesh">Arunachal Pradesh</option>
                                    <option value="Assam">Assam</option>
                                    <option value="Bihar">Bihar</option>
                                    <option value="Chhattisgarh">Chhattisgarh</option>
                                    <option value="Goa">Goa</option>
                                    <option value="Gujarat">Gujarat</option>
                                    <option value="Haryana">Haryana</option>
                                    <option value="HimachalPradesh">HimachalPradesh</option>
                                    <option value="JammuKashmir">JammuKashmir</option>
                                    <option value="Jharkhand">Jharkhand</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="MadhyaPradesh">MadhyaPradesh</option>
                                    <option value="Sehore">Sehore</option>
                                    <option value="Maharashtra">Maharashtra</option>
                                    <option value="Manipur">Manipur</option>
                                    <option value="Meghalaya">Meghalaya</option>
                                    <option value="Mizoram">Mizoram</option>
                                    <option value="Nagaland">Nagaland</option>
                                    <option value="Odisha">Odisha</option>
                                    <option value="Punjab">Punjab</option>
                                    <option value="Rajasthan">Rajasthan</option>
                                    <option value="Sikkim">Sikkim</option>
                                    <option value="TamilNadu">TamilNadu</option>
                                    <option value="Tripura">Tripura</option>
                                    <option value="UttarPradesh">UttarPradesh</option>
                                    <option value="Uttarakhand">Uttarakhand</option>
                                    <option value="WestBengal">WestBengal</option>
                                    <option value="AndamanNicobar">AndamanNicobar</option>
                                    <option value="DamanDiu">DamanDiu</option>
                                    <option value="Lakshadweep">Lakshadweep</option>
                                    <option value="Delhi">Delhi</option>
                                    <option value="Lakshadweep">Lakshadweep</option>
                                    <option value="Puducherry">Puducherry</option>

                                </select>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <div class="">
                                    <input type="text" class="form-control" id="zip" name="zip" placeholder="Pin Code" required>
                                </div>
                            </div>
                        </div>
                        <textarea class="form-control" placeholder="Message" name="message" rows="2" required></textarea>
                        <br>
                        <button type="submit" name="contact" class="btn btn-primary">Send Message</button>                       
                    </form>
                </div>
            </div>
    </section>
    <br>
    <br>
    <style>
    @media (max-width: 767px) {
        .info-item {
            margin-bottom: 20px; /* Adjust the spacing as needed */
        }
    }
    </style>

<section>
<style>
.info-item {
        padding: 20px; /* Add padding inside each info-item */
        height: 100%; /* Set a fixed height */
}

.item-body {
    border: 2px solid black;  /* Add border to each info-item */
    border-color: #02236d;
    border-radius: 20px; /* Add border radius for rounded corners */
    padding: 20px; /* Add padding inside each info-item */
    text-align: center; /* Center align content inside each item-body */
    color: blue;
}

.item-body h3 {
    margin-bottom: 10px; /* Add space below each heading */
    color: blue;
}

.item-body p {
    margin-top: 10px; /* Add space above each paragraph */  
    color: blue;
}

.item-body a {
    margin-top: 10px;
    padding: 20px; /* Add padding inside each info-item */
    margin-bottom: 10px;
    border-radius: 20px; /* Add border radius for rounded corners */
    color: blue; /* Set link color */
}

.info-item-demo {
    margin-top: 0.2px;
    padding: 40px; /* Add padding inside each info-item */
    margin-bottom: 40px;
    border-radius: 20px; /* Add border radius for rounded corners */
    color: blue; /* Set link color */
}

</style>

    <div class="info-item">
    <div class="row row-cols-1 row-cols-md-3 g-4 py-4">
        <div class="col">
                <div class="info-item">
                    <div class="item-body">
                        <h3>
                        <img src="img\icons8-location-40.png" alt="Location Icon" style="width: 40px; height: 40px; display: block; margin: 0 auto; " >
                        </h3>
                        <p>
                    <a href="https://www.google.com/maps/search/?api=1&amp;query=2nd+Floor,+Madhav+Heritage,+Lokmanya+Bal+Gangadhar+Tilak+Rd,Sadashiv+Peth,+Pune,+Maharashtra+411030" target="_blank" style=" text-decoration:none;">2nd Floor, Madhav Heritage, Lokmanya Bal Gangadhar Tilak Rd, 
                    Sadashiv Peth, Pune, Maharashtra 411030"</a>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="col">
                <div class="info-item-demo">
                    <div class="item-body">
                        <h2> 
                        <img src="img\icons8-email-40.png"alt="Mail Icon" style="width: 40px; height: 40px; display: block; margin: 0 auto; ">
                        </h2>
                        <a href="mailto:“ltorpune@gmail.com” style=" text-decoration:none;>ltorpune@gmail.com </a>
                    </div>
                </div>  
            </div>

            <div class="col">
                <div class="info-item">
                    <div class="item-body">
                    <h3> 
                        <img src="img\receiver.png"alt="Contact Icon" style="width: 40px; height: 40px; display: block; margin: 0 auto;" >
                    </h3>
                    <p>
                        <a href="tel:+919403090958" style=" text-decoration:none;">+91 - 9403090958</a>
                        <br>
                            <a href="tel:+919309907928" style=" text-decoration:none;">+91 - 9309907928</a><br>
                            <a href="tel:+919038546718" style=" text-decoration:none;">+91 - 9422301684</a>
                        </p>
                    </p>
                    </div>
                </div>
            </div>
    </div>
    </div>
</section>

<footer>
    <h5 class="p-3 bg-dark text-white text-center">&copy;2024 Placement Management System. All rights reserved.
        <!-- Instagram Icon -->
        <a href="https://www.instagram.com/your_instagram_username" target="_blank" class="text-white mx-2"><i class="fab fa-instagram"></i></a>
        <!-- Facebook Icon -->
        <a href="https://www.facebook.com/your_facebook_page" target="_blank" class="text-white mx-2"><i class="fab fa-facebook"></i></a>
        <!-- YouTube Icon -->
        <a href="https://www.youtube.com/your_youtube_channel" target="_blank" class="text-white mx-2"><i class="fab fa-youtube"></i></a>
        <!-- Another Social Media Icon (e.g., Twitter) -->
        <a href="https://twitter.com/your_twitter_handle" target="_blank" class="text-white mx-2"><i class="fab fa-twitter"></i></a>
    </h5>
</footer>

<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha384-KyZXEAg3QhqLMpG8r+Knujsl5+DVsO2/p7O4b4AHfF6Wq2qqq4JukR5+8a6E21Qc"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-KY+QN54PsR9ad76N3vRmXlTx5lrZMdLx9dmJwG8XBg5Fmm1+OIgFYX6WrplDHBd/"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"
        integrity="sha384-dRD92qerqI6zBPmVR5nOjEQjDnwcB+q4FoUeWjyiV8Jrpa9m+1nH80jPLovXsTSD"
        crossorigin="anonymous"></script>

    <!-- Smooth Scroll -->
    <script>
        $('a[href*="#"]').on('click', function (e) {
            e.preventDefault()

            $('html, body').animate(
                {
                    scrollTop: $($(this).attr('href')).offset().top,
                },
                500,
                'linear'
            )
        })

    </script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>




</body>

</html>









