<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tnp_k"; // Replace 'your_database_name' with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the 'centers' table
$sql = "SELECT * FROM centers";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="col-md-4">';
        echo '<div class="card profile-card">';
        echo '<img src="' . $row["t_center_img"] . '" alt="Center Image" class="card-img-top">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title">' . $row["t_Center_name"] . '</h5>';
        echo '<p class="card-text">Location: ' . $row["t_Location"] . '</p>';
        echo '<p class="card-text">Contact Person: ' . $row["t_Contact_person_nm"] . '</p>';
        echo '<p class="card-text">Email: ' . $row["t_Contact_email"] . '</p>';
        echo '<p class="card-text">Contact: ' . $row["t_Contact_number"] . '</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo "<div class='col-md-12'>No data available</div>";
}

$conn->close();
?>