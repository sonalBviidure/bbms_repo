
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "tnp_k";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["upload"])) {
    // Check if file is uploaded successfully
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
        $targetDir = "gallery_upload/"; // Directory where uploaded files will be saved
        $targetFile = $targetDir . basename($_FILES["image"]["name"]);

        // Move uploaded file to the specified directory
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            // Collect other form data
            $t_gallery_img = $targetFile; // Use the file path as the image value
            $t_gallery_desc = $_POST["image_decs"];

            // Insert data into MySQL database
            $sql = "INSERT INTO gallery (t_gallery_img, t_gallery_desc) VALUES ('$targetDir', '$t_gallery_desc')";

            if ($conn->query($sql) === TRUE) {
                echo "Image uploaded and inserted successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Error uploading file";
        }
    } else {
        echo "No file uploaded or file upload error occurred.";
    }
}

// Close database connection
$conn->close();
?>