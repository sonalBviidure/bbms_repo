<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "tnp_k";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch all data from 'gallery' table
$sql = "SELECT * FROM events";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Events Gallery</title>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Events</h2>
        <div class="row">
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="col-md-4 mb-3">';
                    echo '<div class="card">';
                    echo '<img src="' . $row["event_image"] . '" class="card-img-top" alt="Event Image" style="height: 200px; object-fit: cover;">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . htmlspecialchars($row["event_name"]) . '</h5>';
                    echo '<p class="card-text"><strong>Location:</strong> ' . htmlspecialchars($row["event_location"]) . '</p>';
                    echo '<p class="card-text"><strong>Contact number:</strong> ' . htmlspecialchars($row["event_contact"]) . '</p>';
                    echo '<p class="card-text"><strong>Start Date:</strong> ' . htmlspecialchars($row["start_date"]) . '</p>';
                    echo '<p class="card-text"><strong>End Date:</strong> ' . htmlspecialchars($row["end_date"]) . '</p>';
                    echo '<p class="card-text"><strong>Time:</strong> ' . htmlspecialchars($row["event_time"]) . '</p>';
                    echo '</div>'; // card-body
                    echo '</div>'; // card
                    echo '</div>'; // col
                }
            } else {
                echo '<div class="col-12"><p class="text-center">No records found</p></div>';
            }
            ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
